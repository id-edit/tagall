#By นุ๊กแฮกบอททดลอง
# -*- coding: utf-8 -*-
from linepy import *
from akad.ttypes import Message
from akad.ttypes import ContentType as Type
from akad.ttypes import ChatRoomAnnouncementContents
from akad.ttypes import ChatRoomAnnouncement
from multiprocessing import Pool, Process
from datetime import datetime
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
import time, random, sys, json, codecs, threading, glob, re, string, os, requests, subprocess, six, ast, pytz, urllib.request, urllib.parse, urllib.error, urllib.parse,antolib,subprocess,unicodedata,GACSender
_session = requests.session()
from gtts import gTTS
from googletrans import Translator
#==============================================================================#
botStart = time.time()
#================EvVcY4Nk9hKiJZYdRMW3.TAVOkm2wqPizxdXz1JiGmW.4QUmFeBLiOjPKtdV7+ddmEw6IuVk/aIHke+OWKLmu/Q===============================================================#
#line = LINE()
#line = LINE("เมล","พาส")
line = LINE('EvLpk2OOGXa2gmvFw2Od.T6SPTOgaYVufUrNH3V4kRq.TvRlgNxpT+yqPU8MrNrdImF7ua6ArE88FGwsPY2Hb0o=')
line.log("Auth Token : " + str(line.authToken))
line.log("Timeline Token : " + str(line.tl.channelAccessToken))

print ("Login Succes")

readOpen = codecs.open("read.json","r","utf-8")
settingsOpen = codecs.open("temp.json","r","utf-8")
read = json.load(readOpen)
settings = json.load(settingsOpen)

lineMID = line.profile.mid
lineProfile = line.getProfile()
lineSettings = line.getSettings()

oepoll = OEPoll(line)
#call = Call(line)

Rfu = [line]
Exc = [line]
lineMID = line.getProfile().mid
bot1 = line.getProfile().mid
RfuBot=[lineMID]
Family=["u7b6fcd4b950902cdbc000c79413d6892",lineMID]
admin=['u7b6fcd4b950902cdbc000c79413d6892',lineMID]
RfuFamily = RfuBot + Family
msg_dict = {}
msg_image={}
msg_video={}
msg_sticker={}
unsendchat = {}
temp_flood = {}
wbanlist = []
wblacklist = []
protectname = []
protecturl = []
protection = []
autocancel = {}
autoinvite = []
autoleaveroom = []
targets = []
#==============================================================================#

settings = {
    "autoAdd": True,
    "autoBlock": False,
    "autoJoin": True,
    'autoCancel':{"on":True,"members":10},	
    "autoLeave": True,
    "autoRead": False,
    "autoReply": False,
    "botcancel": False,
    "leaveRoom": False,
    "detectMention": False,
    "checkSticker": False,
    "checkContact": False,
    "checkPost": False,
    "kickMention": False,
    "potoMention": False,
    "delayMention": False,
    "lang":"JP",
    "Wc": True,
    "Lv": True,
    "Nk": True,
    "Api": False,
    "Aip": False,
    "blacklist":{},
    "winvite": False,
    "wblacklist": False,
    "dblacklist": False,
    "detectMentionPM": False,
    "dwhitelist": False,
    "gift": False,
    "likeOn": False,
    "timeline": False,
    "commentOn":True,
    "commentBlack":{},
    "wblack": False,
    "dblack": False,
    "clock": False,
    "cName":"",
    "cNames":"",
    "changeGroupPicture": [],
    "changePictureProfile": False,    
    "changeVideo": False,
    "chatMessage": "dih",
    "unsendMessage": False,
    "autoJoinTicket": False,
    "555":"โอ๊มึงนี้ หนักแล้วนะ ต้องใข้ไฟซ๊อดแล้วนะ",
    "welcome":"『 กรุณาตั้งข้อความคนเข้ากลุ่ม 』",
    "kick":"『 กรุณาตั้งข้อความคนลบกันเอง 』",
    "bye":"『 กรุณาตั้งข้อความคนออก 』",
    "Respontag":""" 『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』 """,
    "eror":"『 คุณได้เล่นคำสั่งผิดกรุณาติดต่อผู้สร้างบอทเพื่อที่จะสอบถามวิธีการใช้งานบอท โปรดพิมพ์ .ผส เพื่อแสดงคอนแทคผู้สร้าง 』",
    "spam":{},
    "invite": {},
    "winvite": False,
    "pnharfbot": {},
    "pname": {},
    "pro_name": {},
    "notag": False,
    "pcancel": False,
    "pinvite": False,
    "pmMessage": "『 มีอะไรหรอครับสนใจบอทรึเปล่าเอ๋ย 』",
    "qrp": False,
    "readerPesan": " 『 ไม่ต้องแอบแล้วววว 』",
    "replyPesan": "Sorry , i'm busy right now.",
    "responGc": False,
    "responcall": False,
    "responcallgc": False,
    "restartPoint": "c07540238e0ddffa5187313406f7f3c67",
    "server": "VPS",
    "ksticker": False,
    "timeRestart": "18000",
    "message1":"『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』",
    "message":"⭐⭐ติดต่องานบอทได้ที่นี้⭐⭐ http://line.me/ti/p/3ylGkIaVj1『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』",
    "comment":"""『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』""",
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ],
    "addPesan": "『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』",
    "addSticker": {
        "name": "",
        "status": False,
    },
    "mentionPesan": " 『 ไงน้อง 』",
    "messageSticker": {
        "addName": "",
        "addStatus": False,
        "listSticker": {
            "addSticker": {
                "STKID": "52002736",
                "STKPKGID": "11537",
                "STKVER": "1"
            },
            "leaveSticker": {
                "STKID": "51626494",
                "STKPKGID": "11538",
                "STKVER": "1"
            },
            "kickSticker": {
                "STKID": "51626530",
                "STKPKGID": "11538",
                "STKVER": "1"
            },
            "readerSticker": {
                "STKID": "13188540",
                "STKPKGID": "1327110",
                "STKVER": "1"
            },
            "responSticker": {
                "STKID": "33158349",
                "STKPKGID": "10788",
                "STKVER": "1"
            },
            "sleepSticker": "",
            "welcomeSticker": {
                "STKID": "22832841",
                "STKPKGID": "1705396",
                "STKVER": "1"
            }
        }
    },
    "mimic": {
       "copy": False,
       "status": False,
       "target": {}
    }
}
RfuProtect = {
    "protect": False,
    "cancelprotect": False,
    "inviteprotect": False,
    "linkprotect": False,
    "Protectguest": False,
    "Protectjoin": False,
    "autoAdd": False,
    "autoBlock": False,
}

Setmain = {
    "foto": {},
}

read = {
    "readPoint": {},
    "readMember": {},
    "readTime": {},
    "setTime":{},
    "ROM": {}
}

myProfile = {
	"displayName": "",
	"statusMessage": "",
	"pictureStatus": ""
}

mimic = {
    "copy":False,
    "copy2":False,
    "status":False,
    "target":{}
    }
    
RfuCctv={
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

rfuSet = {
    'setTime':{},
    'ricoinvite':{},
    'winvite':{},
    }

user1 = lineMID
user2 = ""
	
setTime = {}
setTime = rfuSet['setTime']

contact = line.getProfile() 
backup = line.getProfile() 
backup.dispalyName = contact.displayName 
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus

mulai = time.time() 

myProfile["displayName"] = lineProfile.displayName
myProfile["statusMessage"] = lineProfile.statusMessage
myProfile["pictureStatus"] = lineProfile.pictureStatus
#==============================================================================#
#==============================================================================#
def RhyN_(to, mid):
    try:
        aa = '{"S":"0","E":"3","M":'+json.dumps(mid)+'}'
        text_ = '@Rh'
        line.sendMessage(to, text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
    except Exception as error:
        logError(error)
#==============================================================================================================
                        
def cTime_to_datetime(unixtime):
    return datetime.datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

def delExpire():
    if temp_flood != {}:
        for tmp in temp_flood:
            if temp_flood[tmp]["expire"] == True:
                if time.time() - temp_flood[tmp]["time"] >= 3*10:
                    temp_flood[tmp]["expire"] = False
                    temp_flood[tmp]["time"] = time.time()
                    try:
                        userid = "https://line.me/ti/p/~" + line.profile.userid
                        line.sendFooter(tmp, "Spam is over , Now Bots Actived !", str(userid), "http://dl.profile.line-cdn.net/"+line.getContact(lineMID).pictureStatus, line.getContact(lineMID).displayName)
                    except Exception as error:
                        logError(error)
                        
def load():
    global images
    global stickers
    with open("image.json","r") as fp:
        images = json.load(fp)
    with open("sticker.json","r") as fp:
        stickers = json.load(fp)
        
def sendSticker(to, version, packageId, stickerId):
    contentMetadata = {
        'STKVER': version,
        'STKPKGID': packageId,
        'STKID': stickerId
    }
    line.sendMessage(to, '', contentMetadata, 7)

def sendImage(to, path, name="image"):
    try:
        if settings["server"] == "VPS":
            line.sendImageWithURL(to, str(path))
    except Exception as error:
        logError(error)
def Rapid1Say(mtosay):
    line.sendText(Rapid1To,mtosay)

def delete_log():
    ndt = datetime.datetime.now()
    for data in msg_dict:
        if (datetime.datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]
            
def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = line.genOBSParams({'oid': lineMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = line.server.postContent('{}/talk/vp/upload.nhn'.format(str(line.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        line.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))

def summon(to, nama):
    aa = ""
    bb = ""
    strt = int(14)
    akh = int(14)
    nm = nama
    for mm in nm:
      akh = akh + 2
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 6
      akh = akh + 4
      bb += "\xe2\x95\xa0 @x \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\n"+bb+"\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90"
    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    print ("TAG ALL")
    try:
       line.sendMessage(msg)
    except Exception as error:
       print(error)
def restartBot():
    print ("RESTART SERVER")
    time.sleep(3)
    python = sys.executable
    os.execl(python, python, *sys.argv)
    
def logError(text):
    line.log("[ แจ้งเตือน ] " + str(text))
    time_ = datetime.now()
    with open("errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))

def sendMessage(to, text, contentMetadata={}, contentType=0):
    mes = Message()
    mes.to, mes.from_ = to, profile.mid
    mes.text = text
    mes.contentType, mes.contentMetadata = contentType, contentMetadata
    if to not in messageReq:
        messageReq[to] = -1
    messageReq[to] += 1
        
def sendMessageWithMention(to, lineMID):
    try:
        aa = '{"S":"0","E":"3","M":'+json.dumps(lineMID)+'}'
        text_ = '@x '
        line.sendMessage(to, text_, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
    except Exception as error:
        logError(error)

def myhelp():
    myHelp = """─┅═⭐s̵ᴇʟғʙᴏᴛ ᴛʜᴀɪʟᴀɴᴅ⭐═┅─
⭐NOOK HACK BOT TEAM NOXTYPE⭐
──┅═✥===========✥═┅──
              คำสั่งสำหรับบอท
『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』
──┅═✥===========✥═┅──
คำสั่งทั่วไป
➠.แทค
➠.จับ
➠.อ่าน

คำสั่งแอดมินหรือผู้จ่าย  VIP
➠.ยกเชิญ
➠.ทักเข้า
➠.ทักออก
➠.ทักเตะ



⭐⭐ติดต่องานบอทได้ที่นี้⭐⭐
 http://line.me/ti/p/3ylGkIaVj1

"""
    return myHelp

def listgrup():
    listGrup = """『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』
      ✿คำสั่งในกลุ่ม✿
❊➺ แอด
❊➺ ชื่อกลุ่ม
❊➺ ไอดีกลุ่ม
❊➺ เปิดลิ้ง
❊➺ ปิดลิ้ง
❊➺ ลิ้ง
❊➺ ลิ้งกลุ่ม
❊➺ รายการกลุ่ม
❊➺ สมาชิกกลุ่ม
❊➺ ข้อมูลกลุ่ม
❊➺ รูปกลุ่ม
❊➺ แทค
❊➺ เช็คไอดี
❊➺ ไอดีล่อง
❊➺ คทล่อง
❊➺ แทคล่อง
❊➺ แทค [จำนวน] @
❊➺ คลอ [จำนวน]
❊➺ โทร [จำนวน]
❊➺แทคล่อง
❊➺ จับ
❊➺ เลิกจับ
❊➺ จับใหม่
❊➺ อ่าน
❊➺ คำห้ามพิม [ข้อความ]
❊➺ เช็คคำห้ามพิม
❊➺ ล้างคำห้ามพิม [ข้อความ]
❊➺ แจก [จำนวน] @
❊➺ เปลี่ยนรูปกลุ่ม
❊➺ เปิด/ปิดแสกน
❊➺ เปิด/ปิดรับแขก
❊➺ เปิด/ปิดส่งแขก
❊➺ เปิด/ปิดทักเตะ
❊➺ เปิด/ปิดพูด
❊➺ เปิด/ปิดตรวจสอบ
❊➺ เช็คดำ
❊➺ ลงดำ
❊➺ ล้างดำ
❊➺ ไล่ดำ
❊➺ คทดำ
❊➺ ปวดตับ
『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』"""
    return listGrup

def socmedia():
    socMedia = """『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』
       ✿คำสั่งโซเชลมีเดี่ย✿
❊➺ ปฏิทิน
❊➺ รูปภาพ [ชื่อรูปภาพ]
❊➺ ค้นหารูปภาพ [ชื่อรูปภาพ]
❊➺ ยูทูป [ข้อความ]
❊➺ เพลง [ชื่อเพลง]
❊➺ Lyric
❊➺ ScreenshootWebsite
❊➺ หนัง [ชื่อหนัง]
❊➺ วีดีโอ [ชื่อวีดีโอ]
❊➺ รูปการ์ตูน [ชื่อรูป]
❊➺ ไอจี [ชื่อยูส]
❊➺ Urban
❊➺ google [ข้อความ]
『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』"""
    return socMedia

def helpset():
    helpSet = """『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』
         ✿คำสั่งเซลบอท✿
❊➺ เรา
❊➺ ไอดี
❊➺ ชื่อ
❊➺ ตัส
❊➺ รูปโปร
❊➺ รูปปก
❊➺ วัดรอบ
❊➺ Sp
❊➺ ทักเข้า
❊➺ ติ๊กคนเข้า
❊➺ ลบติ๊กคนเข้า
❊➺ ทักออก
❊➺ ติ๊กคนออก
❊➺ ลบติ๊กคนออก
❊➺ ทักเตะ
❊➺ ติ๊กคนเตะ
❊➺ ลบติ๊กคนเตะ
❊➺ คอมเม้น
❊➺ ข้อความแทค
❊➺ ติ๊กคนแทค
❊➺ ลบติ๊กคนแทค
❊➺ ข้อความแอด
❊➺ ติ๊กคนแอด
❊➺ ลบติ๊กคนแอด
❊➺ ชื่อ:
❊➺ ตัส:
❊➺ ทักเข้า:
❊➺ ตั้งติ๊กคนเข้า
❊➺ ทักออก:
❊➺ ตั้งติ๊กคนออก
❊➺ ทักเตะ:
❊➺ ตั้งติ๊กคนเตะ
❊➺ ตั้งแทค:
❊➺ ตั้งติ๊กคนแทค
❊➺ ตั้งแอด:
❊➺ ตั้งติ๊กคนแอด
❊➺ คอมเม้น:
❊➺ ออน
❊➺ ดำ
❊➺ ขาว
❊➺ แบน @
❊➺ ลบแบน @
❊➺ บล็อค @
❊➺ ลบรัน
❊➺ ดึง
❊➺ ทัก [จำนวน] (แชท.สต)
❊➺ หวด @
❊➺ สอย @
❊➺ ลาก่อย @
❊➺ ปลิว @
❊➺ ดับไฟ
❊➺ แปลงโฉม
❊➺เพื่อน
❊➺ ไอดีเพื่อน
❊➺ Gcancel:(จำนวนสมาชิก)
『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』"""
    return helpSet

def helpsetting():
    helpSetting = """『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』
        ✿คำสั่งการตั้งค่า✿
❊➺  เปิดกัน/ปิดกัน
❊➺ กันยก/ปิดกันยก
❊➺ กันเชิญ/ปิดกันเชิญ
❊➺ กันลิ้ง/ปิดกันลิ้ง
❊➺ กันเข้า/ปิดกันเข้า
❊➺ เปิดหมด/ปิดหมด
❊➺ เปิดกทม/ปิดกทม
❊➺ เปิดเข้า/ปิดเข้า
❊➺ เปิดออก/ปิดออก
❊➺ เปิดติ๊ก/ปิดติ๊ก
❊➺ เปิดบล็อค/ปิดบล็อค
❊➺ เปิดมุด/ปิดมุด
❊➺ เปิดเผือก/ปิดเผือก
❊➺ เปิดอ่าน/ปิดอ่าน
❊➺ เปิดพูด/ปิดพูด
❊➺ เปิดแทค/ปิดแทค
❊➺ เปิดแทค2/ปิดแทค2
❊➺ เปิดแทค3/ปิดแทค3
❊➺ เปิดแทคเจ็บ/ปิดแทคเจ็บ
❊➺ เปิดคท/ปิดคท
❊➺ เปิดตรวจสอบ/ปิดตรวจสอบ
❊➺ เปิดเช็คโพส/ปิดเช็คโพส
❊➺ เปิดแสกน/ปิดแสกน
❊➺ เปิดรับแขก/ปิดรับแขก
❊➺ เปิดส่งแขก/ปิดส่งแขก
❊➺ เปิดทักเตะ/ปิดทักเตะ
❊➺ เปิดข้อความ/ปิดข้อความ
『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』"""
    return helpSetting

def helptexttospeech():
    helpTextToSpeech =   """『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』
   คำสั่งพูดMp3ภาษาต่างๆ
❊➺ af : แอฟริกัน
❊➺ sq : อัลเบเนีย
❊➺ hy : อาเมเนีย
❊➺ bn : เบนจาลี
❊➺ zh-cn : จีน
❊➺ zh-tw : ใต้หวัน
❊➺ cs : เช็ก
❊➺ nl : ดัช
❊➺ en : อังกฤษ
❊➺ en-us : สหรัฐ
❊➺ el : กรีก
❊➺ id : อินโดนีเซีย
❊➺ it : อิตาลี
❊➺ ja : ญี่ปุ่น
❊➺ ko : เกาหลี
❊➺ la : ลาติน
❊➺ ro : โรมาเนีย
❊➺ ru : รัสเซีย
❊➺ sr : เซอเบียร์
❊➺ th : ไทย
❊➺ vi : เวียดนาม
『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』

「วิธีใช้ : say-th สวัสดีครับ」"""
    return helpTextToSpeech
    
def helplanguange():
    helpLanguange =    """『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』
       คำสั่งแปลภาษา
❊➺ af : แอฟริกัน
❊➺ sq : อัลเบเนีย
❊➺ ar : อราบิค
❊➺ hy : อาเมเนีย
❊➺ bn : บังการี่
❊➺ bs : บอสเนีย
❊➺ bg : บังแกเรีย
❊➺ zh-cn : จีน
❊➺ zh-tw : ใต้หวัน
❊➺ cs : เช็ก
❊➺ nl : ดัช
❊➺ en : อังกฤษ
❊➺ et : เอสโตเนียน
❊➺ el : กรีก
❊➺ id : อินโดนีเซีย
❊➺ ga : ไอริส
❊➺ it : อิตาลี
❊➺ ja : ญี่ปุ่น
❊➺ kn : แคนาดา
❊➺ la : ลาติน
❊➺ lv : ลัตเวีย
❊➺ ms : มาเลเซีย
❊➺ mt : มอลเตส
❊➺ mn : มองโกเลีย
❊➺ my : พม่า
❊➺ fa : เปอร์เซีย
❊➺ pt : โปรตุเกศ
❊➺ ro : โรมาเนีย
❊➺ ru : รัสเซีย
❊➺ th : ไทย
❊➺ zu : ซูลู
『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』
 
「วิธีใช้ : tr-th hello」"""
    return helpLanguange
#==============================================================================#
def lineBot(op):
    try:
        if op.type == 0:
            return
        if op.type == 5:
            if settings["autoAdd"] == True:
                line.findAndAddContactsByMid(op.param1)
            if settings["autoBlock"] == True:
                line.blockContact(op.param1)
            msgSticker = settings["messageSticker"]["listSticker"]["addSticker"]
            if msgSticker != None:
                sid = msgSticker["STKID"]
                spkg = msgSticker["STKPKGID"]
                sver = msgSticker["STKVER"]
                sendSticker(op.param1, sver, spkg, sid)
        if op.type == 13:          
            line.acceptGroupInvitation(op.param1)
            line.sendText(op.param1, "เรียกใช้คำสั่ง บอท เพื่อดูเมนูการใช้งาน")                      
        if op.type == 13:
            print ("[ 13 ] มีคนเชิญคุณเข้ากลุ่ม")
            group = line.getGroup(op.param1)
            contact = line.getContact(op.param2)
            if settings["autoJoin"] and lineMID in op.param3:
                line.acceptGroupInvitation(op.param1)
                line.sendMessage(op.param1, op.param2, "สวัสดีครับ", ", ขอบคุณที่เชิญผมเข้ากลุ่มนะ")
        if op.type == 13:
            if lineMID in op.param3:
                G = line.getGroup(op.param1)
                if settings["autoJoin"] == True:
                    if settings["autoCancel"]["off"] == True:
                        if len(G.members) <= settings["autoCancel"]["members"]:
                            line.rejectGroupInvitation(op.param1)
                        else:
                            line.acceptGroupInvitation(op.param1)
                    else:
                        line.acceptGroupInvitation(op.param1)
                elif settings["autoCancel"]["on"] == True:
                    if len(G.members) <= settings["autoCancel"]["members"]:
                        line.rejectGroupInvitation(op.param1)
            else:
                Inviter = op.param3.replace("",',')
                InviterX = Inviter.split(",")
                matched_list = []
                for tag in settings["blacklist"]:
                    matched_list+=[str for str in InviterX if str == tag]
                if matched_list == []:
                    pass
                else:
                    line.cancelGroupInvitation(op.param1, matched_list)
        if op.type == 15:
            #print ("[ 15 ]  NOTIFIED LEAVE GROUP")
            if settings["Lv"] == True:
                if "{gname}" in settings['bye']:
                    gName = line.getGroup(op.param1).name
                    msg = settings['bye'].replace("{gname}", gName)
                    msgSticker = settings["messageSticker"]["listSticker"]["leaveSticker"]
                    if msgSticker != None:
                        sid = msgSticker["STKID"]
                        spkg = msgSticker["STKPKGID"]
                        sver = msgSticker["STKVER"]
                        sendSticker(op.param2, sver, spkg, sid)
                    if "@!" in settings['bye']:
                        msg = msg.split("@!")
                        return sendMention(op.param2, op.param2, msg[0], msg[1])
                    return sendMention(op.param2, op.param2, "Hallo ", msg)
                msgSticker = settings["messageSticker"]["listSticker"]["leaveSticker"]
                if msgSticker != None:
                    sid = msgSticker["STKID"]
                    spkg = msgSticker["STKPKGID"]
                    sver = msgSticker["STKVER"]
                    sendSticker(op.param1, sver, spkg, sid)
                #sendMention(op.param1, op.param2, "Bye", "\n{}".format(str(settings['leavePesan'])))
        if op.type == 19:
            #print ("[ 15 ]  NOTIFIED LEAVE GROUP")
            if settings["Nk"] == True:
                if "{gname}" in settings['kick']:
                    gName = line.getGroup(op.param1).name
                    msg = settings['kick'].replace("{gname}", gName)
                    msgSticker = settings["messageSticker"]["listSticker"]["kickSticker"]
                    if msgSticker != None:
                        sid = msgSticker["STKID"]
                        spkg = msgSticker["STKPKGID"]
                        sver = msgSticker["STKVER"]
                        sendSticker(op.param2, sver, spkg, sid)
                    if "@!" in settings['kick']:
                        msg = msg.split("@!")
                        return sendMention(op.param2, op.param2, msg[0], msg[1])
                    return sendMention(op.param2, op.param2, "Hallo ", msg)
                msgSticker = settings["messageSticker"]["listSticker"]["kickSticker"]
                if msgSticker != None:
                    sid = msgSticker["STKID"]
                    spkg = msgSticker["STKPKGID"]
                    sver = msgSticker["STKVER"]
                    sendSticker(op.param1, sver, spkg, sid)
                #sendMention(op.param1, op.param2, "อุ๊ต๊ะ", "\n{}".format(str(settings['kick'])))
        if op.type == 17:
            print ("[ 17 ]  NOTIFIED ACCEPT GROUP INVITATION")
            if settings["Wc"] == True:
                group = line.getGroup(op.param1)
                contact = line.getContact(op.param2)
                msgSticker = settings["messageSticker"]["listSticker"]["welcomeSticker"]
                if msgSticker != None:
                    sid = msgSticker["STKID"]
                    spkg = msgSticker["STKPKGID"]
                    sver = msgSticker["STKVER"]
                    sendSticker(op.param1, sver, spkg, sid)
        if op.type == 5:
            if RfuProtect["autoAdd"] == True:
                if (settings["comment"] in [""," ","\n",None]):
                    pass
                else:
                    line.sendMessage(op.param1,str(settings["comment"]))
        if op.type == 24:
            if settings["autoLeave"] == True:
                line.leaveRoom(op.param1)                      
        if op.type == 26:
            msg = op.message
            if msg.contentType == 13:
            	if settings["winvite"] == True:
                     if msg._from in admin:
                         _name = msg.contentMetadata["displayName"]
                         invite = msg.contentMetadata["mid"]
                         groups = line.getGroup(msg.to)
                         pending = groups.invitee
                         targets = []
                         for s in groups.members:
                             if _name in s.displayName:
                                 line.sendText(msg.to,"-> " + _name + " \nทำการเชิญสำเร็จ")
                                 break
                             elif invite in settings["blacklist"]:
                                 line.sendText(msg.to,"ขออภัย, " + _name + " บุคคนนี้อยู่ในรายการบัญชีดำ")
                                 line.sendText(msg.to,"ใช้คำสั่ง!, \n➡ล้างดำ➡ดึง" )
                                 break                             
                             else:
                                 targets.append(invite)
                         if targets == []:
                             pass
                         else:
                             for target in targets:
                                 try:
                                     line.findAndAddContactsByMid(target)
                                     line.inviteIntoGroup(msg.to,[target])
                                     line.sendText(msg.to,"เชิญคนนี้สำเร็จแล้ว : \n➡" + _name)
                                     settings["winvite"] = False
                                     break
                                 except:
                                     try:
                                         line.findAndAddContactsByMid(invite)
                                         line.inviteIntoGroup(op.param1,[invite])
                                         settings["winvite"] = False
                                     except:
                                         line.sendText(msg.to,"😧ตรวจพบข้อผิดพลาดที่ไม่ทราบสาเหตุ😩อาจเป็นได้ว่าบัญชีของคุณถูกแบนเชิญ😨")
                                         settings["winvite"] = False
                                         break
        if op.type == 26:
            msg = op.message
            if msg.contentType == 13:
               if settings["wblack"] == True:
                    if msg.contentMetadata["mid"] in settings["commentBlack"]:
                        line.sendText(msg.to,"รับทราบ")
                        settings["wblack"] = False
                    else:
                        settings["commentBlack"][msg.contentMetadata["mid"]] = True
                        settings["wblack"] = False
                        line.sendText(msg.to,"decided not to comment")

               elif settings["dblack"] == True:
                   if msg.contentMetadata["mid"] in settings["commentBlack"]:
                        del settings["commentBlack"][msg.contentMetadata["mid"]]
                        line.sendText(msg.to,"ลบจากรายการที่ถูกแบนแล้ว")
                        settings["dblack"] = False

                   else:
                        settings["dblack"] = False
                        line.sendText(msg.to,"Tidak Ada Dalam Daftar Blacklist")
               elif settings["wblacklist"] == True:
                 if msg._from in admin: 
                   if msg.contentMetadata["mid"] in settings["blacklist"]:
                        line.sendText(msg.to,"Sudah Ada")
                        settings["wblacklist"] = False
                   else:
                        settings["blacklist"][msg.contentMetadata["mid"]] = True
                        settings["wblacklist"] = False
                        line.sendText(msg.to,"เพิ่มบัญชีนี้ในรายการสีดำเรียบร้อยแล้ว")

               elif settings["dblacklist"] == True:
                 if msg._from in admin: 
                   if msg.contentMetadata["mid"] in settings["blacklist"]:
                        del settings["blacklist"][msg.contentMetadata["mid"]]
                        line.sendText(msg.to,"เพิ่มบัญชีนี้ในรายการสีขาวเรียบร้อยแล้ว")
                        settings["dblacklist"] = False

                   else:
                        settings["dblacklist"] = False
                        line.sendText(msg.to,"Tidak Ada Dalam Da ftar Blacklist")
       # if op.type == 26:
#            if settings ["mutebot2"] == True:
           # msg = op.message
           # try:
               # if msg.toType == 0:
                  #  line.log("[%s]"%(msg._from)+str(msg.text))
               # else:
                  #  group = line.getGroup(msg.to)
                    #contact = line.getContact(msg._from)
                  #  line.log("[%s]"%(msg.to)+"\nGroupname: "+str(group.name)+"\nNamenya: "+str(contact.displayName)+"\nPesannya: "+str(msg.text))
               # if msg.contentType == 0:
            #Save message to dict
                    #msg_dict[msg.id] = {"text":msg.text,"from":msg._from,"createdTime":msg.createdTime}
                #if msg.contentType == 7:
                    #stk_id = msg.contentMetadata['STKID']
                    #stk_ver = msg.contentMetadata['STKVER']
                   # pkg_id = msg.contentMetadata['STKPKGID']
                    #ret_ = "="
                    #ret_ += "\nSTICKER ID : {}".format(stk_id)
                  #  ret_ += "\nSTICKER PACKAGES ID : {}".format(pkg_id)
                    #ret_ += "\nSTICKER VERSION : {}".format(stk_ver)
                    #ret_ += "\nSTICKER URL : line://shop/detail/{}".format(pkg_id)
                    #ret_ += "\n"
                    #msg_dict[msg.id] = {"text":str(ret_),"from":msg._from,"createdTime":msg.createdTime}
            #except Exception as e:
                #print(e)                    
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:
                    if sender != line.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
            if msg.contentType == 0:
                if text is None:
                    return
#==============================================================================#
                if msg.text in ["Teston"]:
                    line.sendText(msg.to,"『 SELF BOT BYNOOK』")
                if msg.text in ["นุ๊ก"]:
                    line.sendText(msg.to,"『 ยังอยู่ 』")
                if msg.text in ["เซล","เซลบอท","selfbot","คนรึบอท","Help","help",".help","/help","คำสั่ง"]:
                    line.sendText(msg.to,"💖สนใจ👉ติดตั้งเซลบอท\n👉แก้เซลบอท\n👉เรียนทำเซลบอท 😎\nติดต่อไลน์ไอดี🙋_id_edit_🙋\nราคาคุยกันได้..ชิวๆไม่แพงแน่นอน👌")
                elif text.lower() == '.จับ':
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                    hari = ["วันอาทิตย์", "วันจันทร์", "วันอังคาร", "วันพุธ", "วันพฤหัสบดี", "วันศุกร์", "วันเสาร์"]
                    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                    hr = timeNow.strftime("%A")
                    bln = timeNow.strftime("%m")
                    for i in range(len(day)):
                        if hr == day[i]: hasil = hari[i]
                    for k in range(0, len(bulan)):
                        if bln == str(k): bln = bulan[k-1]
                    readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                    if msg.to in read['readPoint']:
                            try:
                                del read['readPoint'][msg.to]
                                del read['readMember'][msg.to]
                                del read['readTime'][msg.to]
                            except:
                                pass
                            read['readPoint'][msg.to] = msg.id
                            read['readMember'][msg.to] = ""
                            read['readTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                            read['ROM'][msg.to] = {}
                            with open('read.json', 'w') as fp:
                                json.dump(read, fp, sort_keys=True, indent=4)
                                line.sendMessage(msg.to,"Lurking enabled")
                    else:
                        try:
                            del read['readPoint'][msg.to]
                            del read['readMember'][msg.to]
                            del read['readTime'][msg.to]
                        except:
                            pass
                        read['readPoint'][msg.to] = msg.id
                        read['readMember'][msg.to] = ""
                        read['readTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                        read['ROM'][msg.to] = {}
                        with open('read.json', 'w') as fp:
                            json.dump(read, fp, sort_keys=True, indent=4)
                            line.sendMessage(msg.to, "Set reading point:\n" + readTime)
                            

                elif text.lower() == '.อ่าน':
                    tz = pytz.timezone("Asia/Jakarta")
                    timeNow = datetime.now(tz=tz)
                    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                    hari = ["วันอาทิตย์", "วันจันทร์", "วันอังคาร", "วันพุธ", "วันพฤหัสบดี", "วันศุกร์", "วันเสาร์"]
                    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                    hr = timeNow.strftime("%A")
                    bln = timeNow.strftime("%m")
                    for i in range(len(day)):
                        if hr == day[i]: hasil = hari[i]
                    for k in range(0, len(bulan)):
                        if bln == str(k): bln = bulan[k-1]
                    readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                    if receiver in read['readPoint']:
                        if list(read["ROM"][receiver].items()) == []:
                            line.sendMessage(receiver,"[ Reader ]:\nNone")
                        else:
                            chiya = []
                            for rom in list(read["ROM"][receiver].items()):
                                chiya.append(rom[1])
                            cmem = line.getContacts(chiya) 
                            zx = ""
                            zxc = ""
                            zx2 = []
                            xpesan = '[ *** LurkDetector *** ]:\n'
                        for x in range(len(cmem)):
                            xname = str(cmem[x].displayName)
                            pesan = ''
                            pesan2 = pesan+"@c\n"
                            xlen = str(len(zxc)+len(xpesan))
                            xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                            zx = {'S':xlen, 'E':xlen2, 'M':cmem[x].mid}
                            zx2.append(zx)
                            zxc += pesan2
                        text = xpesan+ zxc + "\n[ Lurking time ]: \n" + readTime
                        try:
                            line.sendMessage(receiver, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                        except Exception as error:
                            print (error)
                        pass
                    else:
                        line.sendMessage(receiver,"Lurking has not been set.")
#==============================================================================#
#==============================================================================#

                elif text.lower() == '.แทค':
                    group = line.getGroup(msg.to)
                    nama = [contact.mid for contact in group.members]
                    k = len(nama)//20
                    for a in range(k+1):
                        txt = ''
                        s=0
                        b=[]
                        for i in group.members[a*20 : (a+1)*20]:
                            b.append({"S":str(s), "E" :str(s+6), "M":i.mid})
                            s += 7
                            txt += '@Alin \n'
                        line.sendMessage(to, text=txt, contentMetadata={'MENTION': json.dumps({'MENTIONEES':b})}, contentType=0)
                        line.sendMessage(to, "『 แทคสมาชิกในกลุ่มทั้งหมด 』 {} คน👍".format(str(len(nama))))  
#==============================================================================#
                elif text.lower() == '.ออน':
                    timeNow = time.time()
                    runtime = timeNow - botStart
                    runtime = format_timespan(runtime)
                    line.sendMessage(to, "『 ระยะเวลาการทำงานของบอท {}  』".format(str(runtime)))

#==============================================================================#

                elif '.ทักเตะ: ' in msg.text:
                  if msg._from in admin:
                     spl = msg.text.replace('.ทักเตะ: ','')
                     if spl in [""," ","\n",None]:
                         line.sendMessage(msg.to, "ตั้งข้อความคนคนลบสมาชิดเรียบร้อย")
                     else:
                          settings["kick"] = spl
                          line.sendMessage(msg.to, "『 ตั้งขอความคนเตะกันออกจากกลุ่มแล้วดังนี้  』\n👉{}".format(str(spl)) + "\n\n『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』")

                elif '.ทักออก: ' in msg.text:
                  if msg._from in admin:
                     spl = msg.text.replace('.ทักออก: ','')
                     if spl in [""," ","\n",None]:
                         line.sendMessage(msg.to, "ตั้งข้อความคนออกเรียบร้อย")
                     else:
                          settings["bye"] = spl
                          line.sendMessage(msg.to, "『 ตั้งขอความคนออกกลุ่มแล้วดังนี้  』\n👉{}".format(str(spl)) + "\n\n『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』")

                elif text.lower() == '.join on':
                    settings["autoJoin"] = True
                    line.sendMessage(to, "Autojoin enabled.")
                elif text.lower() == '.join off':
                    settings["autoJoin"] = False
                    line.sendMessage(to, "Auto Join disabled.")
                elif text.lower() == '.มุด on':
                    settings["autoJoinTicket"] = True
                    line.sendMessage(to, "Autojoin byTicket  enabled.")
                elif text.lower() == '.มุด off':
                    settings["autoJoinTicket"] = False
                    line.sendMessage(to, "Autojoin byTicket  disabled.")
#=============================================================================
                elif '.ทักเข้า: ' in msg.text:
                  if msg._from in admin:
                     spl = msg.text.replace('.ทักเข้า: ','')
                     if spl in [""," ","\n",None]:
                         line.sendMessage(msg.to, "ตั้งข้อความคนเข้าเรียบร้อยแล้ว")
                     else:
                          settings["welcome"] = spl
                          line.sendMessage(msg.to, "『 ตั้งขอความคนเข้ากลุ่มแล้วดังนี้  』\n👉{}".format(str(spl)) + "\n\n『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』")
#==============================================================================#
                if text.lower() == '.ยกเชิญ':
                                if msg._from in admin:
                                
                                    if msg.toType == 2:
                                        group = line.getGroup(receiver)
                                        gMembMids = [contact.mid for contact in group.invitee]
                                        k = len(gMembMids)//30
                                        line.sendMessage(msg.to,"『 ยกค้างเชิญจำนวนคนในกลุ่ม {} คน 』 \『 โปรดรอบอทกำลังทำงานสักครู่... 』".format(str(len(gMembMids))))
                                        num=1
                                        for i in range(k+1):
                                            for j in gMembMids[i*30 : (i+1)*30]:
                                                time.sleep(random.uniform(0.5,0.4))
                                                line.cancelGroupInvitation(msg.to,[j])
                                                print ("[Command] "+str(num)+" => "+str(len(gMembMids))+" cancel members")
                                                num = num+1
                                            line.sendMessage(receiver,"『 กรุณารอสักครู่บอทจะยกต่ออีก 30 คน 』\n 『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』")
                                            time.sleep(random.uniform(15,10))
                                        line.sendMessage(receiver,"[『 ยกเลิกเชิญ จำนวน {} คน เรียบร้อยแล้ว 』".format(str(len(gMembMids))))
                                        time.sleep(random.uniform(0.95,1))
                                        line.sendMessage(receiver, None, contentMetadata={"STKID": "64104356","STKPKGID": "4108428","STKVER": "1" }, contentType=7)
                                        gname = line.getGroup(receiver).name
                                        line.sendMessage(Notify,"『 ยกค้างเชิญของกลุ่ม >> "+gname+"  << 』 \n 『 จำนวน {} คน เรียบร้อยแล้ว 』\n 『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』 ".format(str(len(gMembMids))))
                                        time.sleep(random.uniform(0.95,1))
                                        line.leaveGroup(receiver)
                                								
                                    line.sendMessage(receiver,"『 ไม่มีค้างเชิญแล้วนะครับแล้วใช้บริการอีกนะครับ 』\n\n『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』")
                                    line.sendMessage(receiver, None, contentMetadata={"STKID": "64104356","STKPKGID": "4108428","STKVER": "1" }, contentType=7)
                                    line.leaveGroup(receiver)
#=============COMMAND KICKER===========================#

#==============================================================================#
                elif ".gc " in msg.text:
                    bc = msg.text.replace(".gc ","")
                    gid = line.getGroupIdsJoined()
                    for i in gid:
                        line.sendText(i,"ขออนุญาติแอดมิน\n\n"+bc+"\n\n『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』")
                    
                elif ".gg " in msg.text:
                    bc = msg.text.replace(".gg ","")
                    gid = line.getAllContactIds()
                    for i in gid:
                        line.sendText(i,"ขออนุญาติเจ้าของแชท\n\n"+bc+"\n\n『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』")
            
#==============================================================================#
                if text.lower() == 'บอท':
                    myHelp = myhelp()
                    line.sendMessage(to, str(myHelp))
                    line.sendMentionFooter(to, '「ผู้สร้างบอท」\n', sender, "http://line.me/ti/p/3ylGkIaVj1", "http://dl.profile.line-cdn.net/"+line.getContact(sender).pictureStatus, line.getContact(sender).displayName);line.sendMessage(to, line.getContact(sender).displayName, contentMetadata = {'previewUrl': 'http://dl.profile.line-cdn.net/'+line.getContact(sender).pictureStatus, 'i-installUrl': 'http://line.me/ti/p/3ylGkIaVj1', 'type': 'mt', 'subText': "นุ๊กแฮกบอททดลอง", 'a-installUrl': 'http://line.me/ti/p/3ylGkIaVj1', 'a-installUrl': ' http://line.me/ti/p/3ylGkIaVj1', 'a-packageName': 'com.spotify.music', 'countryCode': 'ID', 'a-linkUri': 'http://line.me/ti/p/3ylGkIaVj1', 'i-linkUri': 'http://line.me/ti/p/3ylGkIaVj1', 'id': 'mt000000000a6b79f9', 'text': 'Khie', 'linkUri': 'http://line.me/ti/p/3ylGkIaVj1'}, contentType=19)                            
                    if "/ti/g/" in msg.text.lower():
                        if settings["autoJoinTicket"] == True:
                            link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                            links = link_re.findall(text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                    n_links.append(l)
                            for ticket_id in n_links:
                                group = line.findGroupByTicket(ticket_id)
                                line.acceptGroupInvitationByTicket(group.id,ticket_id)
                                line.sendMessage(to, "『 ระบบ มุดลิ้ง เข้าไปอัตโนมัตแล้ว 』 %s  『 เสร้จสิ้น 』\n\n『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』" % str(group.name))
                if msg.toType == 0 and settings["autoReply"] and sender != lineMID:
                    contact = line.getContact(sender)
                    rjct = ["auto", "ngetag"]
                    validating = [a for a in rjct if a.lower() in text.lower()]
                    if validating != []: return
                    if contact.attributes != 32:
                        msgSticker = settings["messageSticker"]["listSticker"]["sleepSticker"]
                        if msgSticker != None:
                            sid = msgSticker["STKID"]
                            spkg = msgSticker["STKPKGID"]
                            sver = msgSticker["STKVER"]
                            sendSticker(to, sver, spkg, sid)
                        if "@!" in settings["replyPesan"]:
                            msg_ = settings["replyPesan"].split("@!")
                            sendMention(to, sender, "Sleep Mode :\n" + msg_[0], msg_[1])
                        sendMention(to, sender, "Sleep Mode :\nจ๊ะเอ๋", settings["replyPesan"])

        if op.type == 17:
           print ("MEMBER JOIN TO GROUP")
           if settings["Wc"] == True:
             if op.param2 in lineMID:
                 return
             dan = line.getContact(op.param2)
             tgb = line.getGroup(op.param1)
             line.sendMessage(op.param1, str(settings["welcome"]) +"\n".format(str(dan.displayName),str(tgb.name)))
             line.sendContact(op.param1, op.param2)
#             line.sendMessage(op.param1,"สเตตัส\n{}".format(str(dan.statusMessage)))
             line.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net{}".format(dan.picturePath))
        if op.type == 19:
           print ("MEMBER KICKOUT TO GROUP")
           if settings["Nk"] == True:
             if op.param2 in lineMID:
                 return
             dan = line.getContact(op.param2)
             tgb = line.getGroup(op.param1)
             line.sendMessage(op.param1,str(settings["kick"]) + "\n".format(str(dan.displayName)))
             line.sendContact(op.param1, op.param2)
#             line.sendMessage(op.param1,"สเตตัส\n{}".format(str(dan.statusMessage)))
             line.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net{}".format(dan.picturePath))
        if op.type == 15:
           print ("MEMBER LEAVE TO GROUP")
           if settings["Lv"] == True:
             if op.param2 in lineMID:
                 return
             dan = line.getContact(op.param2)
             tgb = line.getGroup(op.param1)
             line.sendMessage(op.param1,str(settings["bye"]) + "\n".format(str(dan.displayName),str(tgb.name)))
             line.sendContact(op.param1, op.param2)
             line.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net{}".format(dan.picturePath)) 
        if op.type == 55:
            try:
                if RfuCctv['cyduk'][op.param1]==True:
                    if op.param1 in RfuCctv['point']:
                        Name = line.getContact(op.param2).displayName
                        if Name in RfuCctv['sidermem'][op.param1]:
                            pass
                        else:
                            RfuCctv['sidermem'][op.param1] += "\n🔰" + Name
                            pref=['🌟ดีคร๊าบผม🌟\n\n『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』','🌟มาแอบอะไรตรงนีัแหม่🌟\n\n『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』','🌟เล่นซ่อนแอบกันเหรอ🌟\n\n『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』','🌟คิดว่าเป็นนินจารึไง🌟\n\n『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』','🌟ว่าไง🌟\n\n『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』','🌟อ่านอย่างเดียวเลยนะ🌟\n\n『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』','🌟ออกมาคุยหน่อย🌟\n\n『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』','🌟ออกมาเดี๋ยวนี้🌟\n\n『 ✨BY.นุ๊กแฮกบอททดลอง✨ 』']
                            sendMessageWithMention(op.param1, op.param2)
                            line.sendMessage(op.param1, str(random.choice(pref)) + '\n♪ ♬ ヾ(´︶`♡)ﾉ ♬ ♪')
                            line.sendContact(op.param1, op.param2)
                            msgSticker = settings["messageSticker"]["listSticker"]["readerSticker"]
                            if msgSticker != None:
                                sid = msgSticker["STKID"]
                                spkg = msgSticker["STKPKGID"]
                                sver = msgSticker["STKVER"]
                                sendSticker(op.param1, sver, spkg, sid)
                    else:
                        pass
                else:
                    pass
            except:
                pass

        if op.type == 55:
            try:
                if RfuCctv['cyduk'][op.param1]==True:
                    if op.param1 in RfuCctv['point']:
                        Name = line.getContact(op.param2).displayName
                        if Name in RfuCctv['sidermem'][op.param1]:
                            pass
                        else:
                            RfuCctv['sidermem'][op.param1] += "\n⌬ " + Name + "\n╚════════════════┛"
                            if " " in Name:
                            	nick = Name.split(' ')
                            if len(nick) == 2:
                            	line.sendMessage(op.param1, "Nah " +nick[0])
                            summon(op.param1, [op.param2])
                    else:
                        pass
                else:
                    pass
            except:
                pass
        if op.type == 55:
            print ("『 SELF BOT NOOK 』")
            try:
                if op.param1 in read['readPoint']:
                    if op.param2 in read['readMember'][op.param1]:
                        pass
                    else:
                        read['readMember'][op.param1] += op.param2
                    read['ROM'][op.param1][op.param2] = op.param2
                    backupData()
                else:
                   pass
            except:
                pass
    except Exception as error:
        logError(error)
#==============================================================================#
def a2():
    now2 = datetime.now()
    nowT = datetime.strftime(now2,"%M")
    if nowT[14:] in ["10","20","30","40","50","00"]:
        return False
    else:
        return True
        

while True:
    try:
        ops = oepoll.singleTrace(count=5)
        if ops is not None:
            for op in ops:
                lineBot(op)
                oepoll.setRevision(op.revision)
    except Exception as e:
        logError(e)

def atend():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")
atexit.register(atend)
